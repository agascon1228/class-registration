/*
#include "list.h"
#include <iostream>
#include <fstream>
 

int main(){
string filename;
    
    List test;
    List test2;
   
    string t1; 
    int t2; 
    
    //TESTING FRONT
    
    cout << "TESTING FRONT: expect krabs, plankton, neptune" << endl; 
    
    test.push_front("krabs", 2);
    
    test.front(t1, t2);
    cout << t1 << " " << t2 << endl; 
    
    test.push_front("plankton", 3);
    
    test.front(t1, t2);
    cout << t1 << " " << t2 << endl; 
    
    test.push_front("neptune", 7);
    
    test.front(t1, t2);
    cout << t1 << " " << t2 << endl << endl; 
        
    //TESTING BACK
    cout << "TESTING BACK: expect wumbo, star, puff" << endl; 
    
    test.push_back("wumbo", 24);
    
    test.back(t1, t2);
    cout << t1 << " " << t2 << endl; 
    
    test.push_back("star", 25);
    
    test.back(t1, t2);
    cout << t1 << " " << t2 << endl; 
    
    test.push_back("puff", 30);
    
    test.back(t1, t2);
    cout << t1 << " " << t2 << endl << endl; 
    
    //TESTING REMOVE
      
    test2.push_back("krabs", 2);
    test2.push_back("plankton", 3);
    test2.push_back("puff", 30);
    test2.push_back("star", 25);
    
    cout << "TESTING REMOVING BACK: expect puff" << endl;
    test2.remove(3);
    cout << t1 << " " << t2 << endl << endl; 
    
    cout << "TESTING REMOVING FRONT: expect plankton" << endl;
    test2.remove(0);
    test2.front(t1, t2);
    cout << t1 << " " << t2 << endl << endl;
    
    //TESTING Retrieve
    cout << "TESTING RETRIEVE: expect larry, spongebob, squidward, sandy " << endl;
    List test3;
    
    test3.push_back("larry", 2);
    test3.push_back("sandy", 3);
    test3.push_back("squidward", 30);
    test3.push_back("spongebob", 25);
    
    test3.retrieve(0, t1, t2);
    cout << t1 << " " << t2 << endl;
    test3.retrieve(3, t1, t2);
    cout << t1 << " " << t2 << endl;
    test3.retrieve(2, t1, t2);
    cout << t1 << " " << t2 << endl;
    test3.retrieve(1, t1, t2);
    cout << t1 << " " << t2 << endl;
   
    
    return 0;
} */

//
// 
// testing for part 2
//
//
#include <iostream>
#include <string>
#include "list.h"

using namespace std;


int main()
{
    List L, L2, L3;
    
    int val2, pos;
    string val1;
    
    try
    {
        cout << "Empty or not: " << L.empty() << endl;  // outputs 1 for false
        L.push_front("hello", 1);
        L.push_back("world", 2);
        L.push_back("happy", 3);
        L.insert(0, "spring", 4);

        cout << "Empty or not: " << L.empty() << endl;  // outputs 1 for false
        L3 = List(L);
        
        cout << "Empty or not: " << L3.empty() << endl;  // outputs 1 for false
        L3.push_back("q", 8);
        L3.push_back("m", 9);
        L3.push_front("a", 10);
        
        cout << "Empty or not: " << L3.empty() << endl;  // outputs 1 for false
        for (int i = 0; i < L.size(); i++)
        {
            L.retrieve(i, val1, val2);
            cout << val1 << " " << val2 << " ";
        }
        cout << endl;
        
        cout << "Count: " << L.size() << endl;
        
        L.front(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        L.back(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        for (int i = 0; i < L3.size(); i++)
        {
            L3.retrieve(i, val1, val2);
            cout << val1 << " " << val2 << " ";
        }
        cout << endl;
        cout << "Count: " << L3.size() << endl;
        
        L3.front(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        L3.back(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        for (int i = 0; i < L.size(); i++)
        {
            L.retrieve(i, val1, val2);
            cout << val1 << " " << val2 << " ";
        }
        cout << endl;
        cout << "Count: " << L.size() << endl;
        
        L.front(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        L.back(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        
        cout << "Empty or not: " << L2.empty() << endl;  // outputs 1 for false
        L2.push_front("hey", 5);
        L2.push_back("hi", 6);
        L2.push_back("good", 7);
        
        cout << "Empty or not: " << L2.empty() << endl;  // outputs 1 for false
        for (int i = 0; i < L2.size(); i++)
        {
            L2.retrieve(i, val1, val2);
            cout << val1 << " " << val2 << " ";
        }
        cout << endl;
        cout << "Count: " << L2.size() << endl;
        
        L2.front(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        L2.back(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        L3 = List(L2);    // this list is L3 and make a deepy copy of the other list L2 into L3 which is empty and not initialized

        cout << "Empty or not: " << L3.empty() << endl;  // outputs 1 for false
        L3.remove(2);
        L3.push_back("q", 8);
        L3.push_back("m", 9);
        L3.push_front("a", 10);
        L3.remove(4);
        
        cout << "Empty or not: " << L3.empty() << endl;  // outputs 1 for false
        pos = L3.search("q");
        
         cout << "Position: " << pos << endl;
        
        for (int i = 0; i < L3.size(); i++)
        {
            L3.retrieve(i, val1, val2);
            cout << val1 << " " << val2 << " ";
        }
        cout << endl;
        cout << "Count: " << L3.size() << endl;
        
        
        L3.front(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        L3.back(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        for (int i = 0; i < L2.size(); i++)
        {
            L2.retrieve(i, val1, val2);
            cout << val1 << " " << val2 << " ";
        }
        cout << endl;
        cout << "Count: " << L2.size() << endl;
        
        
        L2.front(val1, val2);
        cout << val1 << " " << val2 << endl;
        
        L2.back(val1, val2);
        cout << val1 << " " << val2 << endl;
    
    }
    catch (invalid_argument& e)
    {
        
    }

    
    return 0;
} 