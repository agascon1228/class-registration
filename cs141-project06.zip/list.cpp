/*list.cpp*/

//
// Author: Prof. Hummel, U. of I. Chicago, Spring 2021
// 
// Implements a one-way linked-list with optimized insertion at
// head and tail of list. The nodes contain 2 data values, a string
// and an integer.
//

#include <iostream>
#include <string>
#include <exception>
#include <stdexcept>

#include "list.h"

using namespace std;

//
// private member functions:
//

//
// inits this list then makes deep copy of other
//
// Time complexity: O(N)
//
void List::initAndDeepCopy(const List& other)
{
    // Inits this list
    this->Head = nullptr;
    this->Tail = nullptr;
    this->Count = 0;
    
    // Deep copies the contents of the other list into this list
    Node* cur = other.Head;
    while (cur != nullptr) {
        this->push_back(cur->Data.Value1, cur->Data.Value2);
        cur = cur->Next;
    }
}


// 
// free the nodes in the list and resets to empty
//
// Time complexity: O(N)
//
void List::freeAndReset()
{
    Node* cur = this->Head;
    Node* temp = nullptr;
    
    this->Count = 0;
    while (cur != nullptr) {
        temp = cur->Next;
        this->Head = nullptr;
        delete cur;
        cur = temp;
    }
    
    this->Head = nullptr;
    this->Tail = nullptr;
    this->Count = 0;
}

//
// public member functions:
//

//
// default constructor
//
// Initializes the list to empty.
// 
// Time complexity: O(1)
//
List::List()
{
    this->Head = nullptr;
    this->Tail = nullptr;
    this->Count = 0;
}

//
// copy constructor
//
// Makes a deep copy of the other list into this list.
// 
// Time complexity: O(N)
//
List::List(const List& other)
{
    this->initAndDeepCopy(other);
}

//
// destructor
//
// Frees all memory related to this list, and then resets to empty.
// 
// Time complexity: O(N)
//
List::~List()
{
    this->freeAndReset();
}

//
// assignment operator (e.g. L2 = L;)
//
// Makes a deep copy of the other list into this list; since this
// list already exists, the existing elements of this list are freed
// before the copy is made.
// 
// Time complexity: O(N)
//
List& List::operator=(const List& other)
{
   if (this == &other)  // special case: check for L = L;
      return *this;     // do nothing and just return THIS object back

   //
   // This is different from a copy constructor, because "this" list
   // exists and contains nodes.  So we have to free "this" list before
   // we copy the "other" list:
   //
   this->freeAndReset();
   this->initAndDeepCopy(other);

   return *this;  // done, return THIS object back
}

//
// size
//
// Returns the # of elements in the list.
//
// Time complexity: O(1)
//
int List::size()
{
   return this->Count;
}

//
// empty
//
// Returns true if empty, false if not.
//
// Time complexity: O(1)
//
bool List::empty()
{
   return (this->Head == nullptr && this->Tail == nullptr); 
}

//
// search
//
// Search the list for the first occurence of the string value.
// If found, its position in the list is returned. Positions are 
// 0-based, meaning the first node is position 0. If the value is
// not found, -1 is returned.
//
// Time complexity: on average O(N)
//
int List::search(string value)
{
   int pos = 0;
   for (Node* cur = this->Head; cur != nullptr; cur = cur->Next, pos++) {
       if (cur->Data.Value1 == value) {
           return pos;
       }
   }
   return -1;
}

//
// retrieve
//
// Retrieve's the data from node at the given position; the list 
// remains unchanged. Positions are 0-based, meaning the first node
// is position 0. Throws an "invalid_argument" exception if the 
// position is invalid, i.e. 
// throw invalid_argument("List::retrieve: invalid position");
//
// Time complexity: on average O(N)
//
void List::retrieve(int pos, string& value1, int& value2)
{
   int count = 0;      
   if (pos < 0 || pos > this->Count) {
      throw invalid_argument("List::retrieve: invalid position");
   }  
    
   for (Node* cur = this->Head; cur != nullptr; cur = cur->Next, count++) {      
      if (pos == count) {
         value1 = cur->Data.Value1;
         value2 = cur->Data.Value2;
         return;
      }       
   } 
   throw invalid_argument("List::retrieve: invalid position");
}

//
// insert
//
// Inserts the given data in the list such that after
// the insertion, the value is now at the given
// position.
//
// Positions are 0-based, which means a position of 0 
// denotes the data will end up at the head of the list,
// and a position of N (where N = the size of the list)
// denotes the data will end up at the tail of the list.
// If the position is invalid, throws an exception, i.e.
// throw invalid_argument("List::insert: invalid position");
//
// Time complexity: on average O(N)
//
void List::insert(int pos, string value1, int value2)
{
    if (pos < 0 || pos > this->Count) { // If position is invalid
        throw invalid_argument("List::insert: invalid position");
    }      
                         
    Node* cur = this->Head;
    Node* prev = nullptr;

    int count = 0;
    while (cur != nullptr) { // Checks to see where to place this new node by comparing value2.              
        if (pos == count) { // Finds position
            break; // Exits loop to insert it
        }       
        prev = cur;
        cur = cur->Next; // Traverses list, continues comparison
        count++;
    }
    
    Node* newNode = new Node(); 
    newNode->Data.Value1 = value1;
    newNode->Data.Value2 = value2;  
    newNode->Next = nullptr;        
    
    if (prev == nullptr) { // Node is in front, replace head               
        newNode->Next = this->Head;
        this->Head = newNode;   
        
        if (this->Tail == nullptr) {
            this->Tail = newNode;
        }
    }
           
    // Between two nodes or at the end of the list. 
    // Manipulates next pointers to set the new node between two existing nodes.
    else { 
        newNode->Next = cur;
        prev->Next = newNode;
        
        if (cur == nullptr) { // New node at tail.
            this->Tail = newNode;
        }
    }
         
    this->Count++; // Increment the count. 
}

//
// remove
//
// Removes and deletes the node at the given position; no data is
// returned. Positions are 0-based, meaning the first node
// is position 0. Throws an "invalid_argument" exception if the 
// position is invalid, i.e. 
// throw invalid_argument("List::remove: invalid position");
//
// Time complexity: on average O(N)
//
void List::remove(int pos)
{  
    // Throws an error if the position being searched for is negative 
    // or greater than the amount of nodes in the list.
    if (pos < 0 || pos > this->Count) { 
        throw invalid_argument("List::remove: invalid position");
    }
    
    Node* cur = this->Head;
    Node* prev = nullptr;
    
    while (cur != nullptr) {
        if (pos == 0) { // deleting first node, reset head to point to next element                  
            if (prev == nullptr) {
                this->Head = cur->Next;
            }
            
            else {
                prev->Next = cur->Next;
            }  
            
            if (cur->Next == nullptr) {
                this->Tail = prev;
            }
            delete cur;
                       
            this->Count = this->Count - 1;
            return;
        }  
        pos--;
        prev = cur;
        cur = cur->Next;
    }
   throw invalid_argument("List::remove: invalid position");
}

//
// front
//
// Returns the data from the first node in the list. Throws an 
// exception if the list is empty, i.e.
// throw runtime_error("List::front: empty list");
// 
// Time complexity: O(1)
//
void List::front(string& value1, int& value2)
{
    if (this->Count == 0) {
        throw runtime_error("List::front: empty list");
    }
    
    Node* cur = this->Head;
    value1 = cur->Data.Value1;
    value2 = cur->Data.Value2;
}

//
// back
//
// Returns the data from the last node in the list. Throws an 
// exception if the list is empty, i.e.
// throw runtime_error("List::back: empty list");
// 
// Time complexity: O(1)
//
void List::back(string& value1, int& value2)
{
   if (this->Count == 0) {
        throw runtime_error("List::back: empty list");
    }
    
    Node* cur = this->Tail;
    value1 = cur->Data.Value1;
    value2 = cur->Data.Value2;
}

//
// push_front
//
// Inserts the given data at the front of the list.
// 
// Time complexity: O(1)
//
void List::push_front(string value1, int value2)
{
    // Creates new node
    Node* newN = new Node();
    newN->Data.Value1 = value1;
    newN->Data.Value2 = value2;
    
    if (this->Head == nullptr) {
        this->Head = newN;
        this->Tail = newN;
    }
    
    // Connects node to rest of the list, resets head, and increments count.
    else {
       newN->Next = this->Head;
       this->Head = newN; 
    }
        
    this->Count++;   
}

//
// push_back
//
// Inserts the given data at the back of the list.
// 
// Time complexity: O(1)
//
void List::push_back(string value1, int value2)
{
    Node* newN = new Node();
    newN->Data.Value1 = value1;
    newN->Data.Value2 = value2;
    newN->Next = nullptr;
         
    if (this->Tail == nullptr) { // list is empty
       this->Tail = newN;
       this->Head = newN;
    }
    
    else {
        this->Tail->Next = newN;
        this->Tail = newN;
    }
    
    this->Count++;
}