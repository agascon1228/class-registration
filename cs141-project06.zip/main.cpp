/*main.cpp*/

//
// Author: Andrew Gascon
// Assignment: Project 06
// 
// A class-registration system written in C++ that uses five objects and nine commands using data extracted
// from a file. 
//

#include <iostream>
#include <string>
#include <fstream>
#include <exception>
#include <stdexcept>

#include "classreg.h"

using namespace std;

// Function declarations:
void inputFileData(string filename, ClassReg classes[]);
void executeCommands(string& command, ClassReg classes[]);

void listClass(string className, ClassReg classes[]);
void listClassInfo(ClassReg& classes);
void sortNetIDs(string listNetIDs[], int numEnrolled);

void increaseCapacity(string className, int newCapacity, ClassReg classes[]);

void enrollStudent(string className, string netID, ClassReg classes[]);
void enrollIntoClass(ClassReg& classes, string netID);

void waitlistStudent(string className, string netID, int waitlistPosition, ClassReg classes[]);
void placeIntoWaitlist(ClassReg& classes, string netID, int waitlistPosition);

void outputToFile(ClassReg classes[], string outputFile);

//
// inputFileData
// 
// Inputs the data from the enrollments file into each class object
//
void inputFileData(string filename, ClassReg classes[]) {
    ifstream infile;
    infile.open(filename);
    if (!infile.good()) { // Checks if enrollments file is valid
        cout << "**Error: unable to open enrollment file '" << filename << "'" << endl;
        return;
    } 
    
    for (int i = 0; i < 5; i++) {
        string className;
        string netID;

        int capacity;
        int priority;

        infile >> className;
        classes[i].setName(className);

        infile >> capacity;
        classes[i].setCapacity(capacity);

        infile >> netID;
        while (netID != "#") {
            classes[i].enrollStudent(netID);
            infile >> netID;
        }

        infile >> netID;
        while (netID != "#") {
            infile >> priority;
            classes[i].waitlistStudent(netID, priority);
            infile >> netID;
        }
    }
}

//
// listClass
// 
// Lists the information of the class that the user inputs, such as its name, capacity, names and number of
// students enrolled, and names and number of students waitlisted. Will return an error if the class is not
// in the list.
//
void listClass(string className, ClassReg classes[]) {                 
    if (className == "cs111") {
        listClassInfo(classes[0]);
    }
    
    else if (className == "cs141") {
        listClassInfo(classes[1]);       
    }
    
    else if (className == "cs151") {
        listClassInfo(classes[2]);       
    }
    
    else if (className == "cs211") {
        listClassInfo(classes[3]);       
    }
    
    else if (className == "cs251") {
        listClassInfo(classes[4]);       
    }
    
    else {
        cout << "**Invalid class name, try again..." << endl;
    }  
}

//
// sortNetIDs
// 
// Sorts netIDs in alphabetical order
//
void sortNetIDs(string listNetIDs[], int numEnrolled) {
    for (int i = 0; i < numEnrolled - 1; i++) {
        int minIndex = i;
        for (int j = i + 1; j < numEnrolled; j++) {
            if (listNetIDs[j] < listNetIDs[minIndex]) {
                minIndex = j;
            }
        }
        string temp = listNetIDs[i];
        listNetIDs[i] = listNetIDs[minIndex];
        listNetIDs[minIndex] = temp;
    }
} 

//
// listClassInfo
// 
// Lists the information of the class that the user inputs, such as its name, capacity, names and number of
// students enrolled, and names and number of students waitlisted.
//
void listClassInfo(ClassReg& classes) {
    int numEnrolled;
    int numWaitlisted; 
    
    numEnrolled = classes.numEnrolled();
    numWaitlisted = classes.numWaitlisted();    

    cout << classes.getName() << endl;
    cout << "Capacity: " << classes.getCapacity() << endl;
    cout << "Enrolled (" << numEnrolled << "): ";
    
    string* listNetIDs = new string[numEnrolled];
    for (int i = 0; i < numEnrolled; i++) {
        listNetIDs[i] = classes.retrieveEnrolledStudent(i);
    }
    
    sortNetIDs(listNetIDs, numEnrolled);   
    for (int i = 0; i < numEnrolled; i++) {
        cout << listNetIDs[i] << " ";
    }
    cout << endl;
    
    cout << "Waitlisted (" << numWaitlisted << "): ";
    for (int j = 0; j < numWaitlisted; j++) {
        string netID;
        int priority;

        classes.retrieveWaitlistedStudent(j, netID, priority);
        cout << netID << " (" << priority << ") ";
    }
    
    cout << endl;
    delete[] listNetIDs;
}

//
// increaseCapacity
// 
// Changes the enrollment capacity of a specific class. A class's capacity cannot be decreased. Attempting
// to do so will yield as error, as will trying to alter the capacity of a class that isn't on the list.
//
void increaseCapacity(string className, int newCapacity, ClassReg classes[]) {
    int capacity; 
    
    if (className == "cs111") {
        capacity = classes[0].getCapacity();
        if (newCapacity < capacity) {
            cout << "**Error, cannot decrease class capacity, ignored..." << endl;          
        }

        else {
            classes[0].setCapacity(newCapacity);
            cout << classes[0].getName() << endl;
            cout << "Capacity: " << classes[0].getCapacity() << endl;
        }
    }
    
    else if (className == "cs141") {
        capacity = classes[1].getCapacity();
        if (newCapacity < capacity) {
            cout << "**Error, cannot decrease class capacity, ignored..." << endl;          
        }

        else {
            classes[1].setCapacity(newCapacity);
            cout << classes[1].getName() << endl;
            cout << "Capacity: " << classes[1].getCapacity() << endl;
        }       
    }
    
    else if (className == "cs151") {
        capacity = classes[2].getCapacity();
        if (newCapacity < capacity) {
            cout << "**Error, cannot decrease class capacity, ignored..." << endl;          
        }

        else {
            classes[2].setCapacity(newCapacity);
            cout << classes[2].getName() << endl;
            cout << "Capacity: " << classes[2].getCapacity() << endl;
        }      
    }
    
    else if (className == "cs211") {
        capacity = classes[3].getCapacity();
        if (newCapacity < capacity) {
            cout << "**Error, cannot decrease class capacity, ignored..." << endl;          
        }

        else {
            classes[3].setCapacity(newCapacity);
            cout << classes[3].getName() << endl;
            cout << "Capacity: " << classes[3].getCapacity() << endl;
        }      
    }
    
    else if (className == "cs251") {
        capacity = classes[4].getCapacity();
        if (newCapacity < capacity) {
            cout << "**Error, cannot decrease class capacity, ignored..." << endl;          
        }

        else {
            classes[4].setCapacity(newCapacity);
            cout << classes[4].getName() << endl;
            cout << "Capacity: " << classes[4].getCapacity() << endl;
        }      
    }
    
    else {
        cout << "**Invalid class name, try again..." << endl;
    } 
}

//
// enrollStudent
// 
// Actually enrolls the student into a specific class.
//
void enrollStudent(string className, string netID, ClassReg classes[]) {   
    if (className == "cs111") {
        enrollIntoClass(classes[0], netID);
    }
    
    else if (className == "cs141") {
        enrollIntoClass(classes[1], netID);       
    }
    
    else if (className == "cs151") {
        enrollIntoClass(classes[2], netID);       
    }
    
    else if (className == "cs211") {
        enrollIntoClass(classes[3], netID);       
    }
    
    else if (className == "cs251") {
        enrollIntoClass(classes[4], netID);       
    }
    
    else {
        cout << "**Invalid class name, try again..." << endl;
    }   
}

//
// enrollIntoClass
// 
// Enrolls a student, via their netID, into a specific class. Will return an error if the student is being
// enrolled into an invalid class. If the student is already enrolled, nothing happens. If the student is
// in the waitlist, checks to see if there is room in the class. If there is room, the student is removed
// from the waitlist and enrolled into the class. If not, nothing happens and their priority and position
// in the waitlist is unchanged.
// 
// If the student is neither enrolled nor on the waitlist, they are enrolled. If the class is full, the
// student is placed on the waitlist. Their priority is 1 if the waitlist is empty, but if it isn't, their
// priority number is the same as the student at the end of the waitlist, putting this new student at the
// new end.
//
void enrollIntoClass(ClassReg& classes, string netID) {
    int isEnrolled; // Used in searches, -1 if not found, returns index if found.
    int inWaitlist; // Same as above.
    int numWaitlisted;
    
    int numEnrolled;
    int capacity;
    
    isEnrolled = classes.searchEnrolled(netID); // Checks to see if the student is enrolled
    inWaitlist = classes.searchWaitlisted(netID); // Checks if student is waitlisted
    numWaitlisted = classes.numWaitlisted();
    
    numEnrolled = classes.numEnrolled();
    capacity = classes.getCapacity();

    if (isEnrolled != -1) { // If the student is already in the class
        cout << "Student '" << netID << "' enrolled in " << classes.getName() << endl;
        return; // Student already in class, nothing happens.
    }      
    
   else if (inWaitlist != -1) { // If not enrolled, but waitlisted
        if (numEnrolled != capacity) { // Tries to enroll them, checks if class is not at capacity.
            classes.enrollStudent(netID);
            classes.removeWaitlistedStudent(inWaitlist);
            cout << "Student '" << netID << "' enrolled in " << classes.getName() << endl;
        }

        else { // If they can't be enrolled
            cout << "Class full, '" << netID << "' waitlisted for " << classes.getName() << endl;
            return; // Nothing happens, priority and position in waitlisted unchanged.
        }
    }
      
    else {  // Student is neither enrolled nor in the waitlist.
        if (numEnrolled != capacity) { // Tries to enroll them, checks if class is not at capacity.
            classes.enrollStudent(netID);
            cout << "Student '" << netID << "' enrolled in " << classes.getName() << endl;
        }

        else { // Class at capacity, can't be enrolled, waitlists them.
            if (numWaitlisted == 0) { // Waitlist is empty.
                classes.waitlistStudent(netID, 1); // Priority set to 1.
                cout << "Class full, '" << netID << "' waitlisted for " << classes.getName() << endl;
            }
            
            else { // Waitlist not empty.
                // Sets priority to that of the student at the end of the waitlistStudent.
                // Thus putting them at the end of the waitlist.
                int lastPriority;
                string lastNetID;
                
                classes.retrieveWaitlistedStudent(numWaitlisted - 1, lastNetID, lastPriority);
                classes.waitlistStudent(netID, lastPriority);
                cout << "Class full, '" << netID << "' waitlisted for " << classes.getName() << endl;
            }
        }
    } 
} 

//
// waitlistStudent
//
// Places the student into the waitlist for a specific class.
//
void waitlistStudent(string className, string netID, int waitlistPosition, ClassReg classes[]) {
    if (className == "cs111") {
        placeIntoWaitlist(classes[0], netID, waitlistPosition);
    }
    
    else if (className == "cs141") {
        placeIntoWaitlist(classes[1], netID, waitlistPosition);       
    }
    
    else if (className == "cs151") {
        placeIntoWaitlist(classes[2], netID, waitlistPosition);       
    }
    
    else if (className == "cs211") {
        placeIntoWaitlist(classes[3], netID, waitlistPosition);       
    }
    
    else if (className == "cs251") {
        placeIntoWaitlist(classes[4], netID, waitlistPosition);       
    }
    
    else {
        cout << "**Invalid class name, try again..." << endl;
    }
} 

//
// placeIntoWaitlist
//
// Attempts to waitlist the student into the specified class, outputting an error if the class is not on the
// list. If the student is already enrolled, nothing happens. If the student is already in the waitlist, 
// their position is adjusted based on the priority. If the student is neither enrolled nor waitlisted, 
// they are inserted into the waitlist based on priority. 
//
void placeIntoWaitlist(ClassReg& classes, string netID, int waitlistPosition) {
    int inWaitlist;
    int isEnrolled;
    
    inWaitlist = classes.searchWaitlisted(netID); // Checks to see if student is waitlisted
    isEnrolled = classes.searchEnrolled(netID); // Checks to see if student is enrolled

    if (isEnrolled != -1) { // If student is already enrolled.
        cout << "Student '" << netID << "' enrolled in " << classes.getName() << endl;
        return; // Nothing happens.
    }

    else if (inWaitlist != -1) { // Student is already waitlisted.
        classes.removeWaitlistedStudent(inWaitlist);
        classes.waitlistStudent(netID, waitlistPosition);
        cout << "Student '" << netID << "' waitlisted for " << classes.getName() << endl;
    }

    else if (inWaitlist == -1 && isEnrolled == -1) { // Neither waitlisted nor enrolled.
        classes.waitlistStudent(netID, waitlistPosition); 
        cout << "Student '" << netID << "' waitlisted for " << classes.getName() << endl;
    }
}

//
// outputToFile
// 
// Opens the user-input file for output and writes current enrollment data to this file in the same
// format as the enrollments file.
//
void outputToFile(ClassReg classes[], string outputFile) {
    ofstream outfile;
    outfile.open(outputFile);
    
    for (int i = 0; i < 5; i++) {
        int numEnrolled;
        int numWaitlisted;
        int priority;
        string netID;
        
        numEnrolled = classes[i].numEnrolled();
        numWaitlisted = classes[i].numWaitlisted();
        
        outfile << classes[i].getName() << endl;
        outfile << classes[i].getCapacity() << endl;
        
        for (int j = 0; j < numEnrolled; j++) {
            netID = classes[i].retrieveEnrolledStudent(j); 
            outfile << netID << " ";                                
        }
        
        outfile << "#" << endl;
        
        for (int j = 0; j < numWaitlisted; j++) {
            classes[i].retrieveWaitlistedStudent(j, netID, priority); 
            outfile << netID << " " << priority << " ";        
        }
        
        if (i < 4) {
            outfile << "#" << endl;
        }
        
        else if (i == 4) {
            outfile << "#";
        }
    }
    
    outfile.close();
    cout << "Enrollment data output to '" << outputFile << "'" << endl;
}

//
// processCommands
// 
// Takes commands from a text file and processes them into the source code.
//
void processCommands(ClassReg classes[], string commandFile) {
    string command;
    
    ifstream infile;
    infile.open(commandFile);
    if (!infile.good()) { // Checks if command file is valid
        cout << "**Error: unable to open command file '" << commandFile << "'" << endl;
        return;
    } 
    
    cout << "**Processing commands from '" << commandFile << "'" << endl;
    infile >> command;
    while (command != "q" && command != "quit") {        
        if (command == "h" || command == "help") {
            cout << "stats" << endl << "list class" << endl << "increase class capacity" << endl << 
            "enroll class netid" << endl << "waitlist class netid priority" << endl << "process filename" <<
            endl << "output filename" << endl << "quit" << endl;
        }   

        else if (command == "s" || command == "stats") { 
            for (int i = 0; i < 5; i++) {
                cout << classes[i].getName() << ": enrolled=" << classes[i].numEnrolled() << ", waitlisted=" 
                << classes[i].numWaitlisted() << endl;
            }
        }    

        else if (command == "l" || command == "list") {
            string className;
            infile >> className;

            listClass(className, classes);
        }

        else if (command == "i" || command == "increase") {
            string className;
            int newCapacity;

            infile >> className;
            infile >> newCapacity;

            increaseCapacity(className, newCapacity, classes);
        }

        else if (command == "e" || command == "enroll") {
            string className;
            string netID;

            infile >> className;
            infile >> netID;

            enrollStudent(className, netID, classes);
        }

        else if (command == "w" || command == "waitlist") {
            string className;
            string netID;        
            int waitlistPosition;

            infile >> className;
            infile >> netID;
            infile >> waitlistPosition;

            waitlistStudent(className, netID, waitlistPosition, classes);
        }

        else if (command == "p" || command == "process") {
            string commandFile;
            infile >> commandFile;

            processCommands(classes, commandFile);
        }

        else if (command == "o" || command == "output") {
            string outputFile;
            infile >> outputFile;

            outputToFile(classes, outputFile);
        }  

        else {
            cout << "**Invalid command, please try again..." << endl;
        }

        infile >> command;
    }
    
    infile.close();
    cout << "**Done processing '" << commandFile << "'" << endl;
}

//
// executeCommands
//
// Function that calls other functions from it to keep main from being over 100 lines
//
void executeCommands(string& command, ClassReg classes[]) {
    if (command == "h" || command == "help") {
        cout << "stats" << endl << "list class" << endl << "increase class capacity" << endl << 
        "enroll class netid" << endl << "waitlist class netid priority" << endl << "process filename" <<
        endl << "output filename" << endl << "quit" << endl;
    }   
    
    else if (command == "s" || command == "stats") { 
        for (int i = 0; i < 5; i++) {
            cout << classes[i].getName() << ": enrolled=" << classes[i].numEnrolled() << ", waitlisted=" 
            << classes[i].numWaitlisted() << endl;
        }
    }    
    
    else if (command == "l" || command == "list") {
        string className;
        cin >> className;
        
        listClass(className, classes);
    }
    
    else if (command == "i" || command == "increase") {
        string className;
        int newCapacity;
        
        cin >> className;
        cin >> newCapacity;
        
        increaseCapacity(className, newCapacity, classes);
    }
    
    else if (command == "e" || command == "enroll") {
        string className;
        string netID;
        
        cin >> className;
        cin >> netID;
        
        enrollStudent(className, netID, classes);
    }
    
    else if (command == "w" || command == "waitlist") {
        string className;
        string netID;        
        int waitlistPosition;
        
        cin >> className;
        cin >> netID;
        cin >> waitlistPosition;
        
        waitlistStudent(className, netID, waitlistPosition, classes);
    }
    
    else if (command == "p" || command == "process") {
        string commandFile;
        cin >> commandFile;
        
        processCommands(classes, commandFile);
    }
    
    else if (command == "o" || command == "output") {
        string outputFile;
        cin >> outputFile;
        
        outputToFile(classes, outputFile);
    }  
            
    else {
        cout << "**Invalid command, please try again..." << endl;
    }
    
    cout << "Enter a command (help for more info, quit to stop)>" << endl;
    cin >> command;
} 

int main() {   
    ClassReg classes[5]; // contains cs111, cs141, cs151, cs211, and cs251
    string filename;
    string command;
    
    cout << "**CS Enrollment System**" << endl;
    cout << "Enter enrollments filename>" << endl;   
    cin >> filename;        
    
    inputFileData(filename, classes); // Inputs data from the text file into the class objects.
    
    cout << "Enter a command (help for more info, quit to stop)>" << endl;    
    cin >> command;
    while (command != "q" && command != "quit") { // Runs commands unless the quit command is called
        executeCommands(command, classes);
    }
    
    cout << "**Done**" << endl;
    return 0;
} 